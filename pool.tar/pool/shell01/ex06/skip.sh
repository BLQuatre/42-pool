ls -l | sed -n '1~2p'
