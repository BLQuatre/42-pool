#!/bin/sh

find . | wc -l
